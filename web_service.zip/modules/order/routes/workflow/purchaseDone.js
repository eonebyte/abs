export default async function purchaseOrderDone(fastify, opts) {
    fastify.get('/purchases/done', async (request, reply) => {
        try {
            const purchaseOrders = await fastify.order.getPurchaseDone(fastify);
            reply.send(purchaseOrders);
        } catch (error) {
            request.log.error(error);
            reply.status(500).send(error.message);
        }
    });
}