export default async function purchaseOrderOnProgress(fastify, opts) {
    fastify.get('/purchases/onprogress', async (request, reply) => {
        try {
            const { userId } = request.query;
            const purchaseOrders = await fastify.order.getPurchaseOnProgress(fastify, userId);
            reply.send(purchaseOrders);
        } catch (error) {
            request.log.error(error);
            reply.status(500).send(error.message);
        }
    });
}